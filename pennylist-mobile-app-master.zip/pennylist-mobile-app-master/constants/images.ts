import logo from "../assets/icon-512.png";

export default { logo };
